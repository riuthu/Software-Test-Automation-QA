package junitmodule3;

import java.util.HashMap;
import java.util.Map;

public class ContactService {

    private Map<String, Contact> contactMap = new HashMap<>();

    public void addContact(Contact contact) {
        if (contactMap.containsKey(contact.getId())) {
            throw new IllegalArgumentException("Contact with the same ID already exists");
        }
        contactMap.put(contact.getId(), contact);
    }

    public void deleteContact(String id) {
        contactMap.remove(id);
    }

    public boolean updateContactFirstNameById(String id, String firstName) {
        Contact contact = contactMap.get(id);
        if (contact != null) {
            contact.setFirstName(firstName);
            return true;
        }
        return false;
    }

    public boolean updateContactLastNameById(String id, String lastName) {
        Contact contact = contactMap.get(id);
        if (contact != null) {
            contact.setLastName(lastName);
            return true;
        }
        return false;
    }

    public boolean updateContactPhoneById(String id, String phone) {
        Contact contact = contactMap.get(id);
        if (contact != null) {
            contact.setPhone(phone);
            return true;
        }
        return false;
    }

    public boolean updateContactAddressById(String id, String address) {
        Contact contact = contactMap.get(id);
        if (contact != null) {
            contact.setAddress(address);
            return true;
        }
        return false;
    }

    public Map<String, Contact> getContactMap() {
        return contactMap;
    }

    public Contact getContact(String id) {
        return contactMap.get(id);
    }
}
