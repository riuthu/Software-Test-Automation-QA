package junitmodule3;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Map;

public class ContactServiceTest {

    private ContactService contactService;

    @BeforeEach
    public void setUp() {
        contactService = new ContactService();
    }

    @Test
    public void testAddContact() {

        Contact contact = new Contact("1", "John", "Doe", "1234567890", "123 Main St");

        contactService.addContact(contact);

        assertEquals(1, contactService.getContactMap().size());

        Contact addedContact = contactService.getContact("1");

        assertEquals(contact, addedContact);
        assertEquals("1", addedContact.getId());
        assertEquals("John", addedContact.getFirstName());
    }

    @Test
    public void testAddDuplicateContact() {
        Contact contact1 = new Contact("1", "John", "Doe", "1234567890", "123 Main St");
        contactService.addContact(contact1);

        // Adding a contact with the same ID should throw an exception
        assertThrows(IllegalArgumentException.class, () -> {
            Contact contact2 = new Contact("1", "Jane", "Smith", "9876543210", "456 Elm St");
            contactService.addContact(contact2);
        });
    }

    @Test
    public void testDeleteContact() {
        Contact contact = new Contact("1", "John", "Doe", "1234567890", "123 Main St");
        contactService.addContact(contact);

        assertEquals(1, contactService.getContactMap().size());

        contactService.deleteContact("1");

        assertEquals(0, contactService.getContactMap().size());
    }

    @Test
    public void testUpdateContactFirstNameById() {
        Contact contact = new Contact("1", "John", "Doe", "1234567890", "123 Main St");
        contactService.addContact(contact);

        boolean updated = contactService.updateContactFirstNameById("1", "Jane");

        assertTrue(updated);

        Contact updatedContact = contactService.getContact("1");
        assertEquals("Jane", updatedContact.getFirstName());
    }

    @Test
    public void testUpdateContactLastNameById() {
        Contact contact = new Contact("1", "John", "Doe", "1234567890", "123 Main St");
        contactService.addContact(contact);

        boolean updated = contactService.updateContactLastNameById("1", "Smith");

        assertTrue(updated);

        Contact updatedContact = contactService.getContact("1");
        assertEquals("Smith", updatedContact.getLastName());
    }

    @Test
    public void testUpdateContactPhoneById() {
        Contact contact = new Contact("1", "John", "Doe", "1234567890", "123 Main St");
        contactService.addContact(contact);

        boolean updated = contactService.updateContactPhoneById("1", "9876543210");

        assertTrue(updated);

        Contact updatedContact = contactService.getContact("1");
        assertEquals("9876543210", updatedContact.getPhone());
    }

    @Test
    public void testUpdateContactAddressById() {
        Contact contact = new Contact("1", "John", "Doe", "1234567890", "123 Main St");
        contactService.addContact(contact);

        boolean updated = contactService.updateContactAddressById("1", "456 Elm St");

        assertTrue(updated);

        Contact updatedContact = contactService.getContact("1");
        assertEquals("456 Elm St", updatedContact.getAddress());
    }
}
