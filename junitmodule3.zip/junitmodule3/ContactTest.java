package junitmodule3;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class ContactTest {

    @Test
    public void testConstructor() {
        Contact contact = new Contact("1", "John", "Doe", "1234567890", "123 Main St");
        assertEquals("1", contact.getId());
        assertEquals("John", contact.getFirstName());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testInvalidId() {
        new Contact(null, "John", "Doe", "1234567890", "123 Main St");
    }

    @Test(expected = IllegalArgumentException.class)
    public void testInvalidFirstName() {
        new Contact("1", null, "Doe", "1234567890", "123 Main St");
    }

    @Test(expected = IllegalArgumentException.class)
    public void testFirstNameTooLong() {
        new Contact("1", "JohnJohnJohn", "Doe", "1234567890", "123 Main St");
    }

    @Test(expected = IllegalArgumentException.class)
    public void testInvalidLastName() {
        new Contact("1", "John", null, "1234567890", "123 Main St");
    }

    @Test(expected = IllegalArgumentException.class)
    public void testLastNameTooLong() {
        new Contact("1", "John", "DoeDoeDoe", "1234567890", "123 Main St");
    }

    @Test(expected = IllegalArgumentException.class)
    public void testInvalidPhone() {
        new Contact("1", "John", "Doe", null, "123 Main St");
    }

    @Test(expected = IllegalArgumentException.class)
    public void testPhoneWrongLength() {
        new Contact("1", "John", "Doe", "123456789", "123 Main St");
    }

    @Test(expected = IllegalArgumentException.class)
    public void testInvalidAddress() {
        new Contact("1", "John", "Doe", "1234567890", null);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testAddressTooLong() {
        String longAddress = "123 Main Street Apartment 123 This is a really long address";
        new Contact("1", "John", "Doe", "1234567890", longAddress);
    }

}
